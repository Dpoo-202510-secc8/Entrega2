package CatalogoAtracciones;

import java.util.List;

public class Espectaculo {
	public List<String> horarios;
	public List<String> fechas;
	public boolean disponibilidad;

}
