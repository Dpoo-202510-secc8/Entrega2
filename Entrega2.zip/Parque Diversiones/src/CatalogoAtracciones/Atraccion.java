package CatalogoAtracciones;

import java.util.List;

public abstract class Atraccion {
	
	public String nombre;
	public String ubicacion;
	public int cupoMax;
	public int empleadosMin;
	public NivelExclusividad nivelExclusividad;
	public List<String> disponibleClima;
	public boolean prestaServicio;

	public Atraccion(String nombre, String ubicacion, int cupoMax, int empleadosMin,
			NivelExclusividad nivelExclusividad, List<String> disponibleClima, boolean prestaServicio) {
		super();
		this.nombre = nombre;
		this.ubicacion = ubicacion;
		this.cupoMax = cupoMax;
		this.empleadosMin = empleadosMin;
		this.nivelExclusividad = nivelExclusividad;
		this.disponibleClima = disponibleClima;
		this.prestaServicio = prestaServicio;
	}
	
	public String getNombre() {
		return nombre;
	}
	
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getUbicacion() {
		return ubicacion;
	}
	public void setUbicacion(String ubicacion) {
		this.ubicacion = ubicacion;
	}
	public int getCupoMax() {
		return cupoMax;
	}
	public void setCupoMax(int cupoMax) {
		this.cupoMax = cupoMax;
	}
	public int getEmpleadosMin() {
		return empleadosMin;
	}
	public void setEmpleadosMin(int empleadosMin) {
		this.empleadosMin = empleadosMin;
	}
	public NivelExclusividad getNivelExclusividad() {
		return nivelExclusividad;
	}
	public void setNivelExclusividad(NivelExclusividad nivelExclusividad) {
		this.nivelExclusividad = nivelExclusividad;
	}
	public List<String> getDisponibleClima() {
		return disponibleClima;
	}
	public void setDisponibleClima(List<String> disponibleClima) {
		this.disponibleClima = disponibleClima;
	}
	public boolean isPrestaServicio() {
		return prestaServicio;
	}
	public void setPrestaServicio(boolean prestaServicio) {
		this.prestaServicio = prestaServicio;
	}

}