package CatalogoAtracciones;

public class Cultural extends Atraccion{
	public int edadMinima;

}
