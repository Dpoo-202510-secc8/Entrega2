package CatalogoAtracciones;

import java.util.List;

public class Mecanica extends Atraccion{
	
	public double alturaMinima;
	public double alturaMaxima;
	public double pesoMinimo;
	public double pesoMaximo;
	public List<String> contraindicaciones;
	public String nivelRiesgo;

}
